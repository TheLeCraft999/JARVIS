import os
from data import globalvar
import pyttsx3
from colorama import init as cl_init
from colorama import Fore               
from colorama import Style
import datetime as dt
import ast

cl_init()
with open(f'{globalvar.DATA_PATH}', 'r') as file:
        for line in file:
            if line.startswith("devmode="):
                dev_mode = line[len("devmode="):].strip()
with open(globalvar.DATA_PATH, 'r') as file:
            for line in file:
                if line.startswith("voice="):
                    voice = line[len("voice="):].strip()


engine = pyttsx3.init('sapi5')
engine.setProperty('rate', 150)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[int(voice)].id)


def autoimport():
    files = [file for file in os.listdir(globalvar.CMDS_DIR) if os.path.isfile(os.path.join(globalvar.CMDS_DIR, file)) and not file.startswith('_')]
    files.sort()
    engine.say('Please look in the Terminal')
    engine.runAndWait()
    for i, file_name in enumerate(files, start=1):
        if dev_mode == 'true':
            print(f"{Fore.LIGHTBLACK_EX}[{Fore.RED}DEV-MODE{Fore.LIGHTBLACK_EX}]{Style.RESET_ALL} m{i}: {file_name}")
        file_path = os.path.join(globalvar.CMDS_DIR, file_name)
        if os.path.isfile(file_path) and file_name.endswith('.py'):
                with open(file_path, 'r') as file:
                    lines = file.readlines()
                    for line in lines:
                        if line.strip().startswith("def "):
                            function_name = line.split("(")[0].split("def ")[1]

                            args = line.split(")")[0].split("(")[1]
                            if args == '':
                                has_args = False
                            else:
                                has_args = True

                            keyword = input(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} Set a keyword for the {Fore.CYAN}{function_name}{Style.RESET_ALL} command in the {Fore.CYAN}{file_name}{Style.RESET_ALL} File\n> ')
                            with open(globalvar.CONFIG_PATH, 'a') as config_file:
                                if has_args == True:
                                    config_file.write(f'\nm{i};{function_name}(userSaid);{keyword}')
                                else:
                                    config_file.write(f'\nm{i};{function_name};{keyword}')
                            print()
                            
                            