import os
import pyttsx3
from colorama import init as cl_init
from colorama import Fore
from colorama import Style
import datetime as dt
import hashlib



cmds_folder = os.path.dirname(os.path.realpath(__file__))
data_folder = os.path.join(cmds_folder, "..", "data")
data_path = os.path.join(data_folder, "data.txt")
weather_path = os.path.join(data_folder, "weather.txt")

with open(data_path, 'r') as file:
            for line in file:
                if line.startswith("voice="):
                    voice = line[len("voice="):].strip()


engine = pyttsx3.init('sapi5')
engine.setProperty('rate', 150)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[int(voice)].id)


def changePassword():
    engine.say('Please look in the Terminal')
    engine.runAndWait()

    new_pw = input(f'\n{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} New password (type "None" to skip using a password)\n> ')
    confirm_pw = input(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} Confirm password \n> ')

    hashed_pw = generate_password(new_pw)

    if new_pw == confirm_pw:
        if new_pw == None:
            print(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} Please enter a password! If you want to contiune, run this function again')
        else:
            lines = []
            with open(data_path, 'r') as file:
                for line in file:
                    if line.startswith('password'):
                        lines.append(f'password={hashed_pw}\n')
                    else:
                        lines.append(line)

            with open(data_path, 'w') as file:
                file.writelines(lines)
    else:
        print(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} Given passwords didnt match! If you want to contiune, run this function again')


def generate_password(pw):
    sha256_hash = hashlib.sha256()
    sha256_hash.update(pw.encode('utf-8'))
    hashed_string = sha256_hash.hexdigest()

    return hashed_string


