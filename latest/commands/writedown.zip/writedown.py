import pyperclip
import time
import pyautogui


def write(input):
        open_index = input.find('write down ')
        substring = input[open_index + len('write down '):]
        pyperclip.copy(substring)
        time.sleep(2)
        pyautogui.hotkey('ctrl', 'v')