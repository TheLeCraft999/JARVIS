import os
import pyttsx3
from data import globalvar
from colorama import init as cl_init
from colorama import Fore               
from colorama import Style
import datetime as dt

CMDS_DIR = os.path.dirname(os.path.realpath(__file__))
JARVIS_DIR = os.path.dirname(CMDS_DIR)
DATA_DIR = f'{JARVIS_DIR}/data'
ALARM_DIR = f'{DATA_DIR}/alarms'


with open(globalvar.DATA_PATH, 'r') as file:
            for line in file:
                if line.startswith("voice="):
                    voice = line[len("voice="):].strip()


engine = pyttsx3.init('sapi5')
engine.setProperty('rate', 150)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[int(voice)].id)


def addAlarm(userS, keyw):
    index = userS.find(keyw)
    time = userS[index + len(keyw):]

    index = time.find(':')
    actual_time = f'{time[index - 2:index]}:{time[index + len(":"):index + len(":") + 2]}'

    with open(f'{DATA_DIR}/alarms.txt', 'a') as file:
        file.write(actual_time + '\n')


def resetAlarms():
    with open(f'{DATA_DIR}/alarms.txt', 'w') as file:
        pass

def deleteSpecificAlarm(userS, keyw):
    index = userS.find(keyw)
    time = userS[index + len(keyw):]

    index = time.find(':')
    actual_time = f'{time[index - 2:index]}:{time[index + len(":"):index + len(":") + 2]}'
    lines = []
    print(actual_time)
    with open(f'{DATA_DIR}/alarms.txt', 'r') as file:
        for line in file:
            if actual_time in line:
                lines.append('')
            else:
                lines.append(line)
    if lines == []:
       print(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} There is no alarm for {actual_time} set')
       engine.say(f'There is no alarm for {actual_time} set')
    with open(f'{DATA_DIR}/alarms.txt', 'w') as file:
        file.writelines(lines)