from data import globalvar
import os

script_path = f'{globalvar.JARVIS_DIR}/cmds/_alarmclock.py'

os.system(f'start cmd /c "python {script_path}')