import os
import pygame
os.system('cls')
import time
import pyttsx3
import threading
import requests
import datetime as dt
import random
from colorama import init as cl_init
from colorama import Fore
from colorama import Style


CMDS_DIR = os.path.dirname(os.path.realpath(__file__))
JARVIS_DIR = os.path.dirname(CMDS_DIR)
DATA_DIR = f'{JARVIS_DIR}/data'
ALARM_DIR = f'{DATA_DIR}/alarms'
weather_path = os.path.join(f'{JARVIS_DIR}/data', "weather.txt")

with open(f'{DATA_DIR}/data.txt', 'r') as file:
            for line in file:
                if line.startswith("voice="):
                    voice = line[len("voice="):].strip()

engine = pyttsx3.init('sapi5')
engine.setProperty('rate', 150)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[int(voice)].id)


def daytime_greeter():
    if int(dt.datetime.now().strftime("%H")) > 5 and int(dt.datetime.now().strftime("%H")) <= 10:
        return 'Good morning'
    elif int(dt.datetime.now().strftime("%H")) > 10 and int(dt.datetime.now().strftime("%H")) <= 17:
        return 'Good day'
    else:
        return 'Good evening'

def information_readout():

    weather_data = requests.get(f"https://api.openweathermap.org/data/2.5/weather?q=Blaibach&units=metric&APPID=cbf9bd36618a7f4a935c73e76650998b")

    response = requests.get(f"https://api.openweathermap.org/data/2.5/forecast?q=Blaibach&units=metric&appid=cbf9bd36618a7f4a935c73e76650998b")
    data = response.json()
    forecast_data = [(entry["main"]["temp_max"], entry["dt_txt"]) for entry in data["list"]]
    max_temperature, max_temperature_time = max(forecast_data, key=lambda x: x[0])
    max_temperature = int(round(max_temperature, 0))
    max_temperature_hour = max_temperature_time.split()[1][:2]
    #print(weather_data.json())
    current_time = dt.datetime.now().strftime("%H:%M")
    temperature = int(round(weather_data.json()['main']['temp']))
    weather = weather_data.json()['weather'][0]['main']
    description = weather_data.json()['weather'][0]['description']

    greetings_message = daytime_greeter()

    clouds_message = [
        f'{greetings_message} Sir. Its currently {current_time}. The outside temperature is {temperature} degrees Celsius and the peek for today are {max_temperature} degrees celsius. The Weather-Forecast is reporting {description} in the skies for today.',
        f'{greetings_message} Sir. It is currently {current_time} and the outside temperature is {temperature} degrees Celsius. The peek for today are {max_temperature} degrees celsius, and the Weather-Forecast is reporting {description}.',
        f"{greetings_message} Sir. It's currently {current_time}. The outside temperature is {temperature} degrees Celsius and the peak for today is {max_temperature} degrees Celsius. The Weather-Forecast is reporting {description} in the skies for today.",
        f"{greetings_message} Sir. It is {current_time} now. The temperature outside reads {temperature} degrees Celsius, with an expected high of {max_temperature} degrees Celsius. The Weather-Forecast indicates {description} in skies for today.",
        f"{greetings_message} Sir. The time is {current_time}. The temperature outside stands at {temperature} degrees Celsius, with an anticipated high of {max_temperature} degrees Celsius. The Weather-Forecast suggests {description} for today's sky.",
        f"{greetings_message} Sir. At the moment, it's {current_time}. The outside temperature is {temperature} degrees Celsius, with a peak expected at {max_temperature} degrees Celsius. According to the Weather-Forecast, {description} in the skies are expected today.",
        f"{greetings_message} Sir. Currently, the time is {current_time}. The temperature outside is {temperature} degrees Celsius, with a forecasted high of {max_temperature} degrees Celsius. The Weather-Forecast predicts {description} in the skies for today.",
        f"{greetings_message} Sir. The current time is {current_time}. Outside, the temperature reads {temperature} degrees Celsius, with the peak expected to reach {max_temperature} degrees Celsius. The Weather-Forecast anticipates {description} in the skies today.",
        f"{greetings_message} Sir. It's {current_time} right now. The outside temperature is {temperature} degrees Celsius, and it's forecasted to reach a high of {max_temperature} degrees Celsius. The Weather-Forecast indicates {description} in the skies today.",
        f"{greetings_message} Sir. The current time is {current_time}. The temperature outside is {temperature} degrees Celsius, with the highest expected to be {max_temperature} degrees Celsius. According to the Weather-Forecast, {description} in the skies are expected today."
    ]

    clear_message = [
        f"{greetings_message} Sir. It's currently {current_time}. The outside temperature is {temperature} degrees Celsius, and the peak for today is {max_temperature} degrees Celsius. The Weather-Forecast is reporting clear skies for today.",
        f"{greetings_message} Sir. It is {current_time} now. The temperature outside reads {temperature} degrees Celsius, with an expected high of {max_temperature} degrees Celsius. According to the Weather-Forecast, we'll have clear skies today.",
        f"{greetings_message} Sir. The time is {current_time}. The temperature outside stands at {temperature} degrees Celsius, with an anticipated high of {max_temperature} degrees Celsius. Clear skies are forecasted for today according to the Weather-Forecast.",
        f"{greetings_message} Sir. At the moment, it's {current_time}. The outside temperature is {temperature} degrees Celsius, with a peak expected at {max_temperature} degrees Celsius. The Weather-Forecast indicates clear skies for today.",
        f"{greetings_message} Sir. Currently, the time is {current_time}. The temperature outside is {temperature} degrees Celsius, with a forecasted high of {max_temperature} degrees Celsius. According to the Weather-Forecast, clear skies are expected today.",
        f"{greetings_message} Sir. The current time is {current_time}. Outside, the temperature reads {temperature} degrees Celsius, with the peak expected to reach {max_temperature} degrees Celsius. Clear skies are anticipated today, according to the Weather-Forecast.",
        f"{greetings_message} Sir. It's {current_time} right now. The outside temperature is {temperature} degrees Celsius, and it's forecasted to reach a high of {max_temperature} degrees Celsius. The Weather-Forecast predicts clear skies for today.",
        f"{greetings_message} Sir. The current time is {current_time}. The temperature outside is {temperature} degrees Celsius, with the highest expected to be {max_temperature} degrees Celsius. Clear skies are expected today according to the Weather-Forecast.",
        f"{greetings_message} Sir. It's {current_time} now. The outside temperature is {temperature} degrees Celsius, with the peak expected at {max_temperature} degrees Celsius. According to the Weather-Forecast, we can expect clear skies today."
    ]

    rain_message = [
        f"{greetings_message} Sir. It's currently {current_time}. The outside temperature is {temperature} degrees Celsius, and the peak for today is {max_temperature} degrees Celsius. The Weather-Forecast is reporting rain for today.",
        f"{greetings_message} Sir. It is {current_time} now. The temperature outside reads {temperature} degrees Celsius, with an expected high of {max_temperature} degrees Celsius. According to the Weather-Forecast, we're expecting rain today.",
        f"{greetings_message} Sir. The time is {current_time}. The temperature outside stands at {temperature} degrees Celsius, with an anticipated high of {max_temperature} degrees Celsius. Rain is forecasted for today according to the Weather-Forecast.",
        f"{greetings_message} Sir. At the moment, it's {current_time}. The outside temperature is {temperature} degrees Celsius, with a peak expected at {max_temperature} degrees Celsius. The Weather-Forecast indicates rain for today.",
        f"{greetings_message} Sir. Currently, the time is {current_time}. The temperature outside is {temperature} degrees Celsius, with a forecasted high of {max_temperature} degrees Celsius. According to the Weather-Forecast, rain is expected today.",
        f"{greetings_message} Sir. The current time is {current_time}. Outside, the temperature reads {temperature} degrees Celsius, with the peak expected to reach {max_temperature} degrees Celsius. Rain is anticipated today, according to the Weather-Forecast.",
        f"{greetings_message} Sir. It's {current_time} right now. The outside temperature is {temperature} degrees Celsius, and it's forecasted to reach a high of {max_temperature} degrees Celsius. The Weather-Forecast predicts rain for today.",
        f"{greetings_message} Sir. The current time is {current_time}. The temperature outside is {temperature} degrees Celsius, with the highest expected to be {max_temperature} degrees Celsius. Rain is expected today according to the Weather-Forecast.",
        f"{greetings_message} Sir. It's {current_time} now. The outside temperature is {temperature} degrees Celsius, with the peak expected at {max_temperature} degrees Celsius. According to the Weather-Forecast, we can expect rain today.",
        f'{greetings_message} Sir. Its currently {current_time}. The outside temperature is {temperature} degrees Celsius and the peek for today are {max_temperature} degrees celsius. The Weather-Forecast is reporting rain for today.'
    ]

    else_message = [
        f'{greetings_message} Sir. Its currently {current_time}. The outside temperature is {temperature} degrees Celsius and the peek for today are {max_temperature} degrees celsius, also the Weather is {weather}',
        f"{greetings_message} Sir. It's currently {current_time}. The outside temperature is {temperature} degrees Celsius, and the peak for today is {max_temperature} degrees Celsius. Additionally, the Weather is {weather}.",
        f"{greetings_message} Sir. It is {current_time} now. The temperature outside reads {temperature} degrees Celsius, with an expected high of {max_temperature} degrees Celsius. Also, the Weather is {weather}.",
        f"{greetings_message} Sir. The time is {current_time}. The temperature outside stands at {temperature} degrees Celsius, with an anticipated high of {max_temperature} degrees Celsius. The Weather is {weather}.",
        f"{greetings_message} Sir. At the moment, it's {current_time}. The outside temperature is {temperature} degrees Celsius, with a peak expected at {max_temperature} degrees Celsius. Moreover, the Weather is {weather}.",
        f"{greetings_message} Sir. Currently, the time is {current_time}. The temperature outside is {temperature} degrees Celsius, with a forecasted high of {max_temperature} degrees Celsius. Furthermore, the Weather is {weather}.",
        f"{greetings_message} Sir. The current time is {current_time}. Outside, the temperature reads {temperature} degrees Celsius, with the peak expected to reach {max_temperature} degrees Celsius. The Weather is {weather}.",
        f"{greetings_message} Sir. It's {current_time} right now. The outside temperature is {temperature} degrees Celsius, and it's forecasted to reach a high of {max_temperature} degrees Celsius. Additionally, the Weather is {weather}.",
        f"{greetings_message} Sir. The current time is {current_time}. The temperature outside is {temperature} degrees Celsius, with the highest expected to be {max_temperature} degrees Celsius. Also, the Weather is {weather}.",
        f"{greetings_message} Sir. It's {current_time} now. The outside temperature is {temperature} degrees Celsius, with the peak expected at {max_temperature} degrees Celsius. According to the Weather-Forecast, we can expect {weather} today."
    ]

    if weather == 'Clouds':
        engine.say(random.choice(clouds_message))
    elif weather == 'Clear':
        engine.say(random.choice(clear_message))
    elif weather == 'Rain':
        engine.say(random.choice(rain_message))
    else:
        engine.say(random.choice(else_message))

    pygame.init()
    
    pygame.mixer.music.load(f"{ALARM_DIR}/alarm.mp3")
    volume = 2
    pygame.mixer.music.set_volume(volume)
    
    pygame.mixer.music.play()

    time.sleep(6)

    initial_volume = pygame.mixer.music.get_volume()
    target_volume = 0.1

    for _ in range(12):
        current_volume = pygame.mixer.music.get_volume()
        if current_volume > target_volume:
            new_volume = max(target_volume, current_volume - 0.1)
            pygame.mixer.music.set_volume(new_volume)
            time.sleep(0.5)

    engine.runAndWait()

    for _ in range(12):
        current_volume = pygame.mixer.music.get_volume()
        if current_volume < initial_volume:
            new_volume = min(initial_volume, current_volume + 0.1)
            pygame.mixer.music.set_volume(new_volume)
            time.sleep(0.5)

    while pygame.mixer.music.get_busy():
        pygame.time.Clock().tick(10)


def alarm_checker():
    while True:
        with open(f'{DATA_DIR}/alarms.txt', 'r') as file:
            alarm_times = file.readlines()
            alarm_times = [item.strip() for item in alarm_times]
        current_time = dt.datetime.now().strftime("%H:%M")
        if current_time in alarm_times:
            information_readout()
            os.system(f'cmd /c "python {JARVIS_DIR}/cmds/_alarmclock.py')
            quit()
        time.sleep(60)
        
if not os.path.exists(ALARM_DIR):
    os.makedirs(ALARM_DIR)

if not os.path.exists(f'{DATA_DIR}/alarms.txt'):
    with open(f'{DATA_DIR}/alarms.txt', 'w') as file:
        file.close()

if not os.path.exists(f'{DATA_DIR}/weather.txt'):
    print(f'{Fore.MAGENTA}{dt.datetime.now().strftime("[%H:%M:%S]")}{Style.RESET_ALL} Please install and configure the Weather Module first in order to use the Alarm-Module')
    engine.say('Please install and configure the Weathe Module first in order to use the Alarm-Module')
    engine.runAndWait()
    quit()

with open(weather_path, 'r') as file:
                for line in file:
                    if line.startswith("api_key="):
                        api_key = line[len("api_key="):].strip()
                    elif line.startswith("city="):
                        city = line[len("city="):].strip()

print(f'{Fore.RED}DONT CLOSE THIS WINDOW, IT IS ESSENTIAL FOR THE ALARM-CLOCK MODULE{Fore.RESET}')
alarm_checker()